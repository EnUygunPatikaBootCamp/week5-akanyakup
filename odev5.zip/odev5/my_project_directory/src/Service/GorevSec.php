<?php
// src/Service/MessageGenerator.php
namespace App\Service;

class GorevSec
{
    public function gorevSec(): string
    {
        $gorevler = [
            'Kasaya bak!',
            'Masalara Bak!',
            'Alışverişe çık!',
            'Mutfağa bak!',
            'Yerleri süpür!',
            'Yemekleri Yap!',
        ];

        $index = array_rand($gorevler);

        return $gorevler[$index];
    }
}