<?php
// src/Service/MessageGenerator.php
namespace App\Service;

class ElemanSec
{
    public function elemanSec(): string
    {
        $elemanlar = [
            'Ahmet Demirel',
            'Fatih Yalçın',
            'Burak Enes',
            'Derya Karabulut',
            'Dilşad Bulut',
        ];

        $index = array_rand($elemanlar);

        return $elemanlar[$index];
    }
}