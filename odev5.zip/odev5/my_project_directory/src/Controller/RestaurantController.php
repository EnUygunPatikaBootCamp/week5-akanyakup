<?php
namespace App\Controller;

use App\Service\GorevSec;
use App\Service\ElemanSec;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class RestaurantController extends AbstractController
{   

    #[Route('/restaurant/gorevdagilim')]
    public function new(ElemanSec $elemanSec, GorevSec $gorevSec): Response
    {
        $eleman = $elemanSec->elemanSec();
        $gorev = $gorevSec->gorevSec();

        //return new Response ('Bugün '. $eleman.' nın görevi => '.$gorev);
        return $this->render('restaurant/yapilacakisler.html.twig', [
        'eleman' => $eleman,
        'gorev' => $gorev,
    ]);
    }
}